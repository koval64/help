
This is helloworld-daemon readme file.